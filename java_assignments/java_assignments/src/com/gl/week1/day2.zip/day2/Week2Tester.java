package com.gl.week1.day2;
/*
Problem Statement : 
1. As a user I should be able to add the task into an array
2. As a user I should be able to update the task in the array
3. As a user I should be able to delete the task in the array
4. As a user I should be able to search a task from an array 
*/


import java.util.Scanner;

public class Week2Tester {
	public static void main(String[] args) {
		
		int ch = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of tasks you want to store...");
		int size = sc.nextInt();
		
		ArrayOperations operations = new ArrayOperations(size);
		
		do {
			System.out.println("1. Insert new Task");
			System.out.println("2. Delete a Task");
			System.out.println("3. Update a Task");
			System.out.println("4. Search for a Task");
			System.out.println("0. Exit");
			
			System.out.print("Enter your choice : ");
			ch = sc.nextInt();
		
			switch (ch) {
			case 1:
				operations.insertTask();
				break;
			case 2:				
				operations.deleteTask();
				break;
			case 3:				
				operations.updateTask();
				break;
			case 4:				
				operations.searchTask();
				break;
			case 0:
				System.out.println("Good bye!!!");
				break;
			default:
				System.out.println("please check your input your choice does not exists!!!");
			}
		} while (ch != 0);
	}
}