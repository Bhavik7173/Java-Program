package com.gl.week1.day2;


import java.util.Scanner;

public class ArrayOperations {
	// String array to store all the tasks
	String tasks[];
	// represent total number of task are in tasks
	int size = 0;
	Scanner scanner;

	// initialize the tasks array
	public ArrayOperations(int numOfTask) {
		tasks = new String[numOfTask];
		scanner = new Scanner(System.in);
	}

	// insert new task in array of tasks
	public void insertTask() {
		if (size >= tasks.length) {
			System.out.println("Tasks array is overflow!!! you can not insert any more task...");
		} else {
			System.out.println("Enter task you want to insert ... ");
			String task = scanner.nextLine();
			tasks[size] = task;
			size++;
		}
	}

	// delete the task from array of task
	public void deleteTask() {
		if (size <= 0) {
			System.out.println("There are no more Tasks in array...");
		} else {
			System.out.println("Enter task you want to delete ... ");
			String task = scanner.nextLine();
			int index = searchTaskFromArray(task);
			if (index == -1) {
				System.out.println("Task not found!!!");
			} else {
				for (int i = index; i < size - 1; i++) {
					tasks[i] = tasks[i + 1];
				}
				size--;
			}
		}
	}

	// update task
	public void updateTask() {
		if (size == 0) {
			System.out.println("There is no task in array!!!");
		} else {
			System.out.println("Enter task you want to udpate... ");
			String task = scanner.nextLine();

			int index = searchTaskFromArray(task);
			if(index != -1)
			{
				System.out.println("Enter new task ... ");
				String newTask = scanner.nextLine();
				
				tasks[index] = newTask;
				System.out.println("Task updated successfully...");
			}
			else
				System.out.println("Task not found!!!");
		}
	}

	// search the task and remove index of that
	public void searchTask() {
		System.out.println("Enter task you want to search... ");
		String task = scanner.nextLine();
		int index = searchTaskFromArray(task);
		if (index == -1) {
			System.out.println("Task not found");
		} else {
			System.out.println("Your task is on position : " + (index + 1));
		}
	}

	int searchTaskFromArray(String task) {
		int index = -1;
		if (size == 0) {
			System.out.println("There is no task in array!!!");
		} else {
			for (int i = 0; i < size; i++) {
				if (tasks[i].equals(task) == true) {
					return i;
				}
			}
		}
		return index;
	}
	public void disp()
	{
		for(int i=0;i<size;i++)
		{
			System.out.println(tasks[i]);
		}
	}
}
