package com.gi.dao;

public class CartDAO {

}
