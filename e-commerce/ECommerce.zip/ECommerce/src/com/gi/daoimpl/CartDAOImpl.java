package com.gi.daoimpl;

public class CartDAOImpl {

}
